<?php

class __Mustache_1109dea5a7c1b7c119dcf3693e91c999 extends Mustache_Template
{
    public function renderInternal(Mustache_Context $context, $indent = '')
    {
        $buffer = '';

        $buffer .= $indent . '
';
        $buffer .= $indent . '<div class="d-flex flex-column p-3">
';
        $buffer .= $indent . '    <div class="w-25 bg-pulse-grey h6" style="height: 18px"></div>
';
        $buffer .= $indent . '    <div class="w-75 bg-pulse-grey mb-4" style="height: 18px"></div>
';
        $buffer .= $indent . '    <div class="mb-3">
';
        $buffer .= $indent . '        <div class="w-100 d-flex mb-3">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey rounded-circle" style="width: 18px; height: 18px"></div>
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-50 ml-2" style="height: 18px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="w-100 d-flex mb-3">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey rounded-circle" style="width: 18px; height: 18px"></div>
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-50 ml-2" style="height: 18px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="w-100 d-flex mb-3">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey rounded-circle" style="width: 18px; height: 18px"></div>
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-50 ml-2" style="height: 18px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '    <div class="w-50 bg-pulse-grey h6 mb-3 mt-2" style="height: 18px"></div>
';
        $buffer .= $indent . '    <div class="mb-4">
';
        $buffer .= $indent . '        <div class="w-100 d-flex mb-2 align-items-center">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-25" style="width: 18px; height: 27px"></div>
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-25 ml-2" style="height: 18px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '        <div class="w-100 d-flex mb-2 align-items-center">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-25" style="width: 18px; height: 27px"></div>
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-25 ml-2" style="height: 18px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '    <div class="w-25 bg-pulse-grey h6 mb-3 mt-2" style="height: 18px"></div>
';
        $buffer .= $indent . '    <div class="mb-3">
';
        $buffer .= $indent . '        <div class="w-100 d-flex mb-2 align-items-center">
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-25" style="width: 18px; height: 27px"></div>
';
        $buffer .= $indent . '            <div class="bg-pulse-grey w-50 ml-2" style="height: 18px"></div>
';
        $buffer .= $indent . '        </div>
';
        $buffer .= $indent . '    </div>
';
        $buffer .= $indent . '</div>';

        return $buffer;
    }
}
